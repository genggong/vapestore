<?php
/**
 * V17.0.13 — Backfill v2: catat semua order marketplace paid+completed
 * yang BELUM masuk transaksi POS (pos_recorded_at NULL) ke transactions.
 *
 * V2: utamakan bootstrap ROOT (public_html/app) — aplikasi live di hosting
 * memakai struktur CI4 root, bukan legacy/. Fallback ke legacy/.
 *
 * Idempotent & aman diulang.
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

$bootCandidates = [
    __DIR__ . '/../app/bootstrap.php',          // public_html/app/bootstrap.php
    __DIR__ . '/../legacy/app/bootstrap.php',   // fallback legacy
    getcwd() . '/app/bootstrap.php',
    getcwd() . '/legacy/app/bootstrap.php',
];
$loaded = false;
foreach ($bootCandidates as $c) {
    if (file_exists($c)) { require_once $c; $loaded = true; $BOOT = $c; break; }
}
if (!$loaded) { fwrite(STDERR, "bootstrap.php tidak ditemukan. Jalankan dari folder aplikasi (public_html).\n"); exit(1); }

$modCandidates = [
    dirname($BOOT) . '/Modules/Marketplace/Marketplace.php',
    __DIR__ . '/../app/Modules/Marketplace/Marketplace.php',
    __DIR__ . '/../legacy/app/Modules/Marketplace/Marketplace.php',
    getcwd() . '/app/Modules/Marketplace/Marketplace.php',
];
$modLoaded = false;
foreach ($modCandidates as $c) {
    if (file_exists($c)) { require_once $c; $modLoaded = true; $MOD = $c; break; }
}
if (!$modLoaded || !function_exists('marketplace_record_pos_transaction')) {
    fwrite(STDERR, "Marketplace.php (module) tidak ditemukan / fungsi record tidak ada. Timpa dulu app/Modules/Marketplace/Marketplace.php dgn versi v17.0.12+.\n");
    exit(1);
}
if (!class_exists('Database')) { fwrite(STDERR, "Database class tidak ada.\n"); exit(1); }

echo "boot  : {$BOOT}\n";
echo "module: {$MOD}\n\n";

$db = Database::connect();
// pastikan kolom pos_recorded_at ada
marketplace_install($db);

$cand = $db->query(
    "SELECT id, order_number FROM online_orders
     WHERE payment_status='paid' AND order_status='completed' AND pos_recorded_at IS NULL
     ORDER BY id ASC"
)->fetchAll() ?: [];

echo "Kandidat belum tercatat POS: " . count($cand) . "\n";
$ok = 0; $fail = 0;
foreach ($cand as $c) {
    try {
        $res = marketplace_record_pos_transaction($db, (int)$c['id']);
        if ($res !== null) { echo "  OK  order #{$c['id']} ({$c['order_number']}) -> transaksi #{$res}\n"; $ok++; }
        else { echo "  SKIP order #{$c['id']} (belum memenuhi syarat / sudah tercatat)\n"; }
    } catch (Throwable $e) {
        echo "  GAGAL order #{$c['id']}: " . $e->getMessage() . "\n";
        $fail++;
    }
}
echo "Selesai: {$ok} tercatat, {$fail} gagal.\n";