<?php

$password = 'admin123';

$hash = password_hash($password, PASSWORD_DEFAULT);

echo "<h3>Password asli:</h3>";
echo "<code>" . htmlspecialchars($password) . "</code>";

echo "<h3>Hash password:</h3>";
echo "<textarea style='width:100%;height:120px'>" . htmlspecialchars($hash) . "</textarea>";

