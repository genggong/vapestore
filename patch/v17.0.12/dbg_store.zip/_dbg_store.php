<?php
// DEBUG STORE - hapus setelah selesai. Render persis seperti router index.php dgn error visible
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('log_errors', '1');
header('Content-Type: text/plain; charset=utf-8');

echo "=== DEBUG STORE ===\n";
echo "cwd = " . getcwd() . "\n";
echo "__DIR__ = " . __DIR__ . "\n";

$appDir = __DIR__ . '/app';
if (!file_exists($appDir . '/bootstrap.php')) {
    // coba relatif lain
    foreach ([__DIR__.'/../app', dirname(__DIR__).'/app'] as $c) { if (file_exists($c.'/bootstrap.php')) { $appDir=$c; break; } }
}
echo "appDir = $appDir (bootstrap " . (file_exists($appDir.'/bootstrap.php') ? 'ADA':'TIDAK') . ")\n";

try {
    require_once $appDir . '/bootstrap.php';
    echo "bootstrap OK\n";
    echo "store/index.php ada? " . (file_exists(__DIR__.'/store/index.php') ? 'YA':'TIDAK') . "\n";
    echo "store/_data.php ada? " . (file_exists(__DIR__.'/store/_data.php') ? 'YA':'TIDAK') . "\n";
    echo "Auth::check() = " . (class_exists('Auth') && Auth::check() ? 'true' : 'false') . "\n";
    echo "=== RENDER store/index.php ===\n";
    ob_start();
    require __DIR__ . '/store/index.php';
    $html = ob_get_clean();
    echo "[render selesai, " . strlen($html) . " bytes]\n";
    echo substr(strip_tags($html), 0, 200) . "\n";
    echo "\n=== SELESAI TANPA FATAL ===\n";
} catch (Throwable $e) {
    echo "\n=== FATAL ===\nMSG : " . $e->getMessage() . "\nFILE: " . $e->getFile() . ":" . $e->getLine() . "\nTRACE:\n" . $e->getTraceAsString() . "\n";
}