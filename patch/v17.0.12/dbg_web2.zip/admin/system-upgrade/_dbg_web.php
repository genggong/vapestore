<?php
// DEBUG WEB v2 - otomatis temukan app/ lalu render index.php asli (hapus setelah selesai)
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('log_errors', '1');

session_start();
$_SESSION['auth_user'] = [
    'id' => 1, 'username' => 'admin', 'role_slug' => 'super_admin', 'role_id' => 1,
    'nama' => 'Admin Debug', 'email' => 'admin@vapekongstore.com', 'branch_id' => 1,
];
$_SESSION['csrf'] = bin2hex(random_bytes(16));

header('Content-Type: text/plain; charset=utf-8');
echo "=== DEBUG WEB v2 ===\n";
echo "__DIR__ = " . __DIR__ . "\n";

$base = __DIR__; // .../admin/system-upgrade
$candidates = [
    dirname($base, 2) . '/app',              // public_html/app  <- benar utk hosting ini
    dirname($base, 3) . '/public_html/app',  // fallback
    dirname($base, 3) . '/app',              // ~/app
    getcwd() . '/app',
];
$appDir = null;
foreach ($candidates as $c) {
    if (file_exists($c . '/bootstrap.php')) { $appDir = $c; break; }
}
echo "appDir = " . ($appDir ?: 'TIDAK ADA') . "\n";
if (!$appDir) {
    echo "Kandidat dicek:\n";
    foreach ($candidates as $c) echo "  {$c}/bootstrap.php: " . (file_exists($c . '/bootstrap.php') ? 'ADA' : 'tidak') . "\n";
    exit;
}

try {
    require_once $appDir . '/bootstrap.php';
    echo "bootstrap OK | Auth::check() = " . (Auth::check() ? 'true' : 'false') . "\n";
    $mod = $appDir . '/Modules/System/SystemUpgrade.php';
    echo "SystemUpgrade: " . (file_exists($mod) ? 'ADA' : 'TIDAK ADA') . "  ($mod)\n";
    if (file_exists($mod)) {
        require_once $mod;
        echo "module OK | vk_sys_upgrade = " . (function_exists('vk_sys_upgrade') ? 'ADA' : 'TIDAK ADA') . "\n";
    }
    echo "=== RENDER index.php ASLI ===\n";
    ob_start();
    require __DIR__ . '/index.php';
    $html = ob_get_clean();
    echo "[render selesai, " . strlen($html) . " bytes output]\n";
    echo substr(strip_tags($html), 0, 500) . "\n";
    echo "\n=== SELESAI: TIDAK ADA FATAL ===\n";
} catch (Throwable $e) {
    echo "\n=== FATAL ===\nMSG : " . $e->getMessage() . "\nFILE: " . $e->getFile() . ":" . $e->getLine() . "\nTRACE:\n" . $e->getTraceAsString() . "\n";
}