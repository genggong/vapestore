<?php
// DEBUG WEB - hapus file ini setelah selesai (aman utk debug singkat)
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('log_errors', '1');

session_start();
$_SESSION['auth_user'] = [
    'id' => 1, 'username' => 'admin', 'role_slug' => 'super_admin', 'role_id' => 1,
    'nama' => 'Admin Debug', 'email' => 'admin@vapekongstore.com', 'branch_id' => 1,
];
$_SESSION['csrf'] = bin2hex(random_bytes(16));

header('Content-Type: text/plain; charset=utf-8');
echo "=== DEBUG WEB START ===\n";
$appDir = dirname(__DIR__, 3) . '/app';
echo "appDir = {$appDir}\n";
echo "bootstrap ada? " . (file_exists($appDir . '/bootstrap.php') ? 'YA' : 'TIDAK') . "\n";
try {
    require_once $appDir . '/bootstrap.php';
    echo "bootstrap OK | Auth::check() = " . (Auth::check() ? 'true' : 'false') . "\n";
    require_once $appDir . '/Modules/System/SystemUpgrade.php';
    echo "module OK | vk_sys_upgrade = " . (function_exists('vk_sys_upgrade') ? 'ADA' : 'TIDAK ADA') . "\n";
    echo "=== RENDER index.php ===\n";
    ob_start();
    require __DIR__ . '/index.php';
    $html = ob_get_clean();
    echo "render OK, panjang = " . strlen($html) . " bytes\n";
    echo "=== DEBUG WEB SELESAI (TIDAK ADA FATAL) ===\n";
} catch (Throwable $e) {
    echo "\n=== FATAL ===\n";
    echo "MSG : " . $e->getMessage() . "\n";
    echo "FILE: " . $e->getFile() . ":" . $e->getLine() . "\n";
    echo "TRACE:\n" . $e->getTraceAsString() . "\n";
}