# VAPESTORE POS — PATCH GABUNGAN (v17.0.11b + v17.0.12)

Satu paket berisi SEMUA perbaikan terbaru. Timpa file di hosting, jalankan script tools, selesai.

---

## 1. Nilai Modal Stok POS = Excel/Stock Opname (v17.0.11b)
**Masalah:** laporan POS nilai modal stok beda 225.000 dengan Excel/template stock opname.
Produk Dripstate Butter Bread 60ml: harga beli INDUK 0, tapi 2 variannya stok 1x1 @ 112.500 = 225.000.
Laporan lama pakai harga induk (0) → selisih 225.000.

**Perbaikan (`reports/stock.php`):** produk ber-varian dengan harga induk 0 dihitung pakai
stok x harga beli VARIAN. Hasil = **61.939.048** (sama persis Excel).

## 2. Password Pelanggan Marketplace (v17.0.11b)
- Semua member aktif tanpa password di-set default **vapekong123** — jalankan `tools/set_default_password.php` di server (sekali saja)
- Login marketplace: **No HP + password**
- Admin set/reset: Menu Pelanggan → Edit → "Password Marketplace" (`customers/edit.php`)
- Pelanggan bisa ganti sendiri di halaman Profil

## 3. Harga Beli Stok = RATA-RATA TERTIMBANG (v17.0.12)
**Masalah:** setiap beli produk yang sudah ada dengan harga beda, harga belinya langsung ditimpa harga baru.
Jadi stok lama (harga murah) ikut terhitung mahal / stok baru terhitung murah — nilai modal jadi tidak akurat.

**Cara baru (contoh):**
- Ada stok 10 botol @ Rp 100.000 → nilai 1.000.000
- Beli lagi 10 botol @ Rp 150.000 → tambah 1.500.000
- Total stok 20 botol, total modal 2.500.000 → harga beli sekarang = **2.500.000 / 20 = 125.000/botol**

**Berlaku di:**
- `purchases/create.php` — pembelian supplier (ke gudang atau cabang)
- `stock-requests/action.php` — saat gudang mengirim barang ke cabang (fulfill request)
- HPP master produk & varian ikut di-update ke rata-rata
- Helper: `purchases/_helpers.php` fungsi `avg_hpp()`

## 4. Display Request Stock ala POS (v17.0.12)
`assets/js/stock-request.js` — stok gudang di daftar produk **berkurang otomatis**
sesuai qty di keranjang, pill merah/hijau ikut berubah, tombol + nonaktif kalau sisa habis.

---

## Cara Pasang
1. **Backup** dulu di hosting
2. **Timpa** 6 file sesuai folder (reports/stock.php, customers/edit.php, purchases/_helpers.php, purchases/create.php, stock-requests/action.php, assets/js/stock-request.js)
3. **Jalankan** `php tools/set_default_password.php` (CLI) — set password vapekong123 utk member yg belum punya
4. Hapus tools/ setelah selesai
5. Hard refresh browser (Ctrl+F5) biar JS baru kebaca

## File di zip ini
- legacy/public/admin/reports/stock.php — nilai modal varian (61.939.048)
- legacy/public/admin/customers/edit.php — field password marketplace (admin)
- tools/set_default_password.php — script isi password default member
- legacy/public/admin/purchases/_helpers.php — helper avg_hpp()
- legacy/public/admin/purchases/create.php — HPP rata-rata tertimbang saat pembelian
- legacy/public/admin/stock-requests/action.php — HPP rata-rata saat fulfill request stok
- legacy/public/assets/js/stock-request.js — display request stok ala POS

Verifikasi: lint PHP OK, unit test avg_hpp 5/5 PASS. v17.0.11b + v17.0.12 sudah di-repo github.com/genggong/vapestore.
