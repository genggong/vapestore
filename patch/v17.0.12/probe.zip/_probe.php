<?php
// PROBE - tampilkan lingkungan web server (hapus setelah selesai)
error_reporting(E_ALL);
ini_set('display_errors', '1');
header('Content-Type: text/plain; charset=utf-8');

echo "=== PROBE ENV ===\n";
echo "DOCUMENT_ROOT  = " . ($_SERVER['DOCUMENT_ROOT'] ?? '(kosong)') . "\n";
echo "SCRIPT_NAME    = " . ($_SERVER['SCRIPT_NAME'] ?? '') . "\n";
echo "PHP_SELF       = " . ($_SERVER['PHP_SELF'] ?? '') . "\n";
echo "REQUEST_URI    = " . ($_SERVER['REQUEST_URI'] ?? '') . "\n";
echo "getcwd()       = " . getcwd() . "\n";
echo "__DIR__        = " . __DIR__ . "\n";
echo "PHP_SAPI       = " . PHP_SAPI . "\n";
echo "\n=== CEK FILE PENTING (relatif ke __DIR__) ===\n";
$checks = [
    'store/index.php', 'store/login.php', 'store/_data.php',
    'app/bootstrap.php', 'app/Modules/System/SystemUpgrade.php',
    'admin/system-upgrade/index.php', 'legacy/app/bootstrap.php',
    'index.php',
];
foreach ($checks as $c) {
    $p = __DIR__ . '/' . $c;
    echo str_pad($c, 45) . (file_exists($p) ? 'ADA  ' . filesize($p) . 'B' : 'TIDAK') . "\n";
}
echo "\n=== CEK BEBERAPA LOKASI APP (coba tampilkan) ===\n";
foreach ([__DIR__.'/../app', __DIR__.'/app', '/home/vapekong/app'] as $a) {
    echo str_pad($a, 50) . (file_exists($a.'/bootstrap.php') ? 'bootstrap ADA' : '-') . "\n";
}
echo "\n=== SELESAI ===\n";